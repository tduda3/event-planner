import pytest
from app import create_app, db as _db

@pytest.fixture(scope='session')
def app():
    """Session-wide Flask application for tests."""
    # Create the app with testing config
    app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:'
    })
    yield app

@pytest.fixture(scope='session')
def db(app):
    """Session-wide initialized database."""
    # Create all tables once, under app context
    with app.app_context():
        _db.create_all()
    yield _db
    # Drop all tables at session end
    with app.app_context():
        _db.drop_all()

@pytest.fixture(scope='function', autouse=True)
def session(app, db):
    """Creates a nested transaction for a test, rolls back after."""
    # Ensure we are in the app context
    ctx = app.app_context()
    ctx.push()

    # Start a transaction and bind the session to it
    connection = db.engine.connect()
    transaction = connection.begin()
    # bind session to this connection
    _db_session = db.session
    _db_session.bind = connection

    # start a nested transaction (savepoint)
    nested = _db_session.begin_nested()

    yield _db_session

    # Rollback nested transaction and outer transaction
    nested.rollback()
    transaction.rollback()
    # remove session and pop app context
    db.session.remove()
    connection.close()
    ctx.pop()

@pytest.fixture(scope='function')
def client(app):
    """Flask test client."""
    return app.test_client()