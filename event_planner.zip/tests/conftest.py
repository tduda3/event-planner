import pytest
from app import create_app, db as _db

@pytest.fixture(scope='session')
def app():
    """Create a Flask app instance for tests."""
    app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:'
    })
    yield app

@pytest.fixture(scope='session')
def db(app):
    """Initialize the database schema once per test session."""
    with app.app_context():
        _db.create_all()
    yield _db
    with app.app_context():
        _db.drop_all()

@pytest.fixture(scope='module', autouse=True)
def reset_db(app, db):
    """Reset database schema before each test module (test file)."""
    with app.app_context():
        _db.drop_all()
        _db.create_all()
    yield

@pytest.fixture(scope='function', autouse=True)
def _app_context(app, db):
    """Push an application context for each test, then pop it."""
    ctx = app.app_context()
    ctx.push()
    yield
    # Clean up DB session and pop context
    _db.session.remove()
    ctx.pop()

@pytest.fixture(scope='function')
def client(app):
    """Provide a Flask test client for HTTP requests."""
    return app.test_client()