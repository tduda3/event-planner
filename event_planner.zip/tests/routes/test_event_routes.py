import pytest
from datetime import datetime

# Helpers for user auth and event payload

def register_and_login(client, username='host', email='host@example.com', password='pass1234'):
    client.post('/users/register', json={'username': username, 'email': email, 'password': password})
    login = client.post('/users/login', json={'email': email, 'password': password})
    token = login.get_json()['access_token']
    return token


def event_payload():
    return {
        'title': 'Networking Lunch',
        'datetime': '2025-08-15T12:00:00',
        'location': 'Office Cafeteria',
        'description': 'Meet and greet with team'
    }


def test_list_events_empty(client):
    resp = client.get('/events/')
    assert resp.status_code == 200
    data = resp.get_json()
    assert data['events'] == []
    assert data['total'] == 0


def test_create_event_success(client):
    token = register_and_login(client)
    resp = client.post(
        '/events/',
        json=event_payload(),
        headers={'Authorization': f'Bearer {token}'}
    )
    assert resp.status_code == 201
    data = resp.get_json()
    assert data['title'] == 'Networking Lunch'
    assert data['owner_id'] == 1


def test_create_event_missing_fields(client):
    token = register_and_login(client)
    resp = client.post(
        '/events/',
        json={'datetime': '2025-08-15T12:00:00'},
        headers={'Authorization': f'Bearer {token}'}
    )
    assert resp.status_code == 400
    assert 'error' in resp.get_json()


def test_get_event_success(client):
    token = register_and_login(client)
    # create event
    create = client.post('/events/', json=event_payload(), headers={'Authorization': f'Bearer {token}'})
    event_id = create.get_json()['id']

    resp = client.get(f'/events/{event_id}')
    assert resp.status_code == 200
    data = resp.get_json()
    assert data['id'] == event_id
    assert data['title'] == 'Networking Lunch'


def test_get_event_not_found(client):
    resp = client.get('/events/999')
    assert resp.status_code == 404
    assert 'error' in resp.get_json()


def test_update_event_success(client):
    token = register_and_login(client)
    create = client.post('/events/', json=event_payload(), headers={'Authorization': f'Bearer {token}'})
    event_id = create.get_json()['id']

    update_resp = client.put(
        f'/events/{event_id}',
        json={'title': 'Updated Title'},
        headers={'Authorization': f'Bearer {token}'}
    )
    assert update_resp.status_code == 200
    data = update_resp.get_json()
    assert data['title'] == 'Updated Title'


def test_update_event_permission_denied(client):
    token1 = register_and_login(client, username='alice', email='a@example.com')
    token2 = register_and_login(client, username='bob', email='b@example.com')
    create = client.post('/events/', json=event_payload(), headers={'Authorization': f'Bearer {token1}'})
    event_id = create.get_json()['id']

    resp = client.put(
        f'/events/{event_id}',
        json={'title': 'Hacked'},
        headers={'Authorization': f'Bearer {token2}'}
    )
    assert resp.status_code == 403


def test_delete_event_success(client):
    token = register_and_login(client)
    create = client.post('/events/', json=event_payload(), headers={'Authorization': f'Bearer {token}'})
    event_id = create.get_json()['id']

    resp = client.delete(
        f'/events/{event_id}',
        headers={'Authorization': f'Bearer {token}'}
    )
    assert resp.status_code == 200


def test_delete_event_not_found(client):
    token = register_and_login(client)
    resp = client.delete('/events/999', headers={'Authorization': f'Bearer {token}'})
    assert resp.status_code == 404